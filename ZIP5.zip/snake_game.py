# Modern Snake Game by Joel Anang (R1812D7151618) 

# Importing needed libraries
import pygame  # For game development
import sys  # For system-related operations
import random  # To generate random numbers
import math  # For mathematical operations
import os  # For file and directory operations
import pygame.mixer  # To handle audio
import time  # For timing operations

# Initializing Pygame
pygame.init()
pygame.mixer.init()


# Check if the game is running as a script or frozen executable
if getattr(sys, 'frozen', False):
    application_path = sys._MEIPASS
else:
    application_path = os.path.dirname(os.path.abspath(__file__))

# Set up the game icon
icon_path = os.path.join(application_path, 'icon.png')
if os.path.exists(icon_path):
    try:
        game_icon = pygame.image.load(icon_path)
        pygame.display.set_icon(game_icon)
    except pygame.error:
        print(f"Warning: Unable to load icon file at {icon_path}")
else:
    print(f"Warning: Icon file not found at {icon_path}")

# Setting up font paths and sizes (I used "samsung sharp sans bold" for readability)
font_path = os.path.join(os.path.dirname(__file__), 'samsungsharpsansbold.otf')
font_size_large = 50
font_size_medium = 30
font_size_small = 15

# Create font objects for different sizes
font_large = pygame.font.Font(font_path, font_size_large)
font_medium = pygame.font.Font(font_path, font_size_medium)
font_small = pygame.font.Font(font_path, font_size_small)

# Setting up the game's window dimensions
WIDTH, HEIGHT = 1366, 768
DISPLAY = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
WIDTH, HEIGHT = DISPLAY.get_size()
pygame.display.set_caption("Modern Snake Game")

# Load and play audio
bite_sound = pygame.mixer.Sound("Music/bite.mp3")
pygame.mixer.music.load("Music/background.mp3")
pygame.mixer.music.play(-1)  # The -1 makes it loop indefinitely

# Defining the colors to be used (in RGB format)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 200, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
PINK = (255, 192, 203)

# The game grid
GRID_SIZE = 20
GRID_WIDTH = WIDTH // GRID_SIZE
GRID_HEIGHT = HEIGHT // GRID_SIZE

# Initialize snake position and direction
snake = [(GRID_WIDTH // 2, GRID_HEIGHT // 2)]
snake_direction = (1, 0)

# Initialize AI snake position and direction
ai_snake = [(GRID_WIDTH // 4, GRID_HEIGHT // 4)]
ai_snake_direction = (1, 0)

# Initialize food position
food = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))

# Create a clock object to control game speed
clock = pygame.time.Clock()

# Initialize scores
score = 0
ai_score = 0

# Initialize high score
high_score = 0

# Create a font object for displaying text
font = pygame.font.Font(None, 36)

# Create a background surface with a grid-like pattern
background = pygame.Surface((WIDTH, HEIGHT))
for y in range(0, HEIGHT, GRID_SIZE):
    for x in range(0, WIDTH, GRID_SIZE):
        color = (0, 50, 0) if (x + y) // GRID_SIZE % 2 == 0 else (0, 60, 0)
        pygame.draw.rect(background, color, (x, y, GRID_SIZE, GRID_SIZE))

# Define difficulty levels (frames per second [FPS])
DIFFICULTY_EASY = 5
DIFFICULTY_MEDIUM = 10
DIFFICULTY_HARD = 15
current_difficulty = DIFFICULTY_MEDIUM # starting difficulty until player changes it

# Set up the power-up variables
POWERUP_DURATION = 6 * current_difficulty  # stays for 6 seconds
POWERUP_SPAWN_INTERVAL = 12 * current_difficulty  # appears every 12 secs
powerup = None
powerup_timer = 0
time_since_last_powerup = 0

# Defining the game modes
GAME_MODE_BASIC = "Basic"
GAME_MODE_AI_OPPONENT = "AI Opponent"
GAME_MODE_CAGE = "Cage"
current_game_mode = GAME_MODE_BASIC # till user changes mode

# Audio settings
is_muted = False

# Game metrics variables (for quantitative analysis)
frame_count = 0
game_load_time = 0
game_start_time = 0
game_duration = 0
snake_length = 1
ai_snake_length = 1
game_over_cause = ""
ai_wins = 0
ai_losses = 0

# variable to store game state when paused
paused_game_state = None

def spawn_powerup():
    """Spawn a power-up every 12 seconds if one doesn't exist"""
    global powerup, powerup_timer, time_since_last_powerup
    if current_game_mode != GAME_MODE_AI_OPPONENT:  # No power-ups in AI opponent mode
        time_since_last_powerup += 1
        if time_since_last_powerup >= POWERUP_SPAWN_INTERVAL and not powerup:
            powerup = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))
            powerup_timer = POWERUP_DURATION
            time_since_last_powerup = 0

def move_snake():
    """Move the snake and handle collisions"""
    global snake, food, score, powerup, powerup_timer, high_score, snake_length, game_over_cause, time_since_last_powerup
    # Calculate new head position
    if current_game_mode != GAME_MODE_CAGE:
        new_head = ((snake[0][0] + snake_direction[0]) % GRID_WIDTH, 
                    (snake[0][1] + snake_direction[1]) % GRID_HEIGHT)
    else:
        new_head = (snake[0][0] + snake_direction[0], 
                    snake[0][1] + snake_direction[1])
    
    # Check for collision with self or walls in Cage mode
    if new_head in snake[1:]:
        game_over_cause = "Self-collision"
        return False  # Game over
    elif current_game_mode == GAME_MODE_CAGE and (new_head[0] < 0 or new_head[0] >= GRID_WIDTH or 
                                                  new_head[1] < 0 or new_head[1] >= GRID_HEIGHT):
        game_over_cause = "Edge collision"
        return False  # Game over
    
    # Add new head to the snake
    snake.insert(0, new_head)
    
    # Check for collisions with food or power-up
    if snake[0] == food:
        bite_sound.play()  # Play bite sound
        # Spawn new food
        food = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))
        score += 1
        snake_length += 1
        if score > high_score:
            high_score = score
        spawn_powerup()
        if current_game_mode == GAME_MODE_AI_OPPONENT and score >= 10:
            game_over_cause = "Player win"
            return False  # Game over
    elif powerup and snake[0] == powerup:
        bite_sound.play()  # Play bite sound
        score += 2  # Power-up is worth 2 points
        snake_length += 2
        if score > high_score:
            high_score = score
        powerup = None
        powerup_timer = 0
        time_since_last_powerup = 0  # Reset the timer when power-up is collected
        if current_game_mode == GAME_MODE_AI_OPPONENT and score >= 10: # 10 bites determines the winner
            game_over_cause = "Player win"
            return False  # Game over
    else:
        # Remove tail if no food was eaten
        snake.pop()
    
    return True

def move_ai_snake():
    """Move the AI snake towards the food"""
    global ai_snake, food, ai_score, ai_snake_length, game_over_cause

    # Get current head position and food position
    head_x, head_y = ai_snake[0]
    food_x, food_y = food

    # Determine direction to move towards food
    if head_x < food_x:
        new_direction = (1, 0)
    elif head_x > food_x:
        new_direction = (-1, 0)
    elif head_y < food_y:
        new_direction = (0, 1)
    else:
        new_direction = (0, -1)

    # Calculate new head position
    new_head = ((head_x + new_direction[0]) % GRID_WIDTH, 
                (head_y + new_direction[1]) % GRID_HEIGHT)

    # Check for collisions and adjust direction if necessary
    if new_head in ai_snake[1:] or new_head in snake:
        safe_directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        random.shuffle(safe_directions)
        for direction in safe_directions:
            new_head = ((head_x + direction[0]) % GRID_WIDTH, 
                        (head_y + direction[1]) % GRID_HEIGHT)
            if new_head not in ai_snake[1:] and new_head not in snake:
                new_direction = direction
                break

    # Move the AI snake
    new_head = ((head_x + new_direction[0]) % GRID_WIDTH, 
                (head_y + new_direction[1]) % GRID_HEIGHT)
    ai_snake.insert(0, new_head)

    # Check for AI snake food collision
    if ai_snake[0] == food:
        bite_sound.play()  # Play bite sound
        food = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))
        ai_score += 1
        ai_snake_length += 1
        if ai_score >= 10:
            game_over_cause = "AI win"
            return False
    else:
        ai_snake.pop()

    return True

def draw_score():
    """Draw the score(s) and high score on the screen"""
    if current_game_mode == GAME_MODE_AI_OPPONENT:
        player_score_surface = font.render(f'Player: {score}/10', True, WHITE)
        ai_score_surface = font.render(f'AI: {ai_score}/10', True, WHITE)
        DISPLAY.blit(player_score_surface, (10, 10))
        DISPLAY.blit(ai_score_surface, (WIDTH - ai_score_surface.get_width() - 10, 10))
    else:
        score_surface = font.render(f'Score: {score}', True, WHITE)
        DISPLAY.blit(score_surface, (10, 10))
    
    high_score_surface = font.render(f'High Score: {high_score}', True, WHITE)
    DISPLAY.blit(high_score_surface, (10, 50))

# Game over screen and result 
def game_over_screen():
    """Display the game over screen and handle restart"""
    global ai_wins, ai_losses, game_duration
    DISPLAY.fill(BLACK)
    game_over_text = font.render('Game Over', True, WHITE)
    score_text = font.render(f'Final Score: {score}', True, WHITE)
    high_score_text = font.render(f'High Score: {high_score}', True, WHITE)
    cause_text = font.render(f'Cause: {game_over_cause}', True, WHITE)
    duration_text = font.render(f'Game Duration: {game_duration:.2f} seconds', True, WHITE)
    restart_text = font.render('Press SPACE to restart', True, WHITE)
    
    DISPLAY.blit(game_over_text, (WIDTH//2 - game_over_text.get_width()//2, HEIGHT//6))
    DISPLAY.blit(score_text, (WIDTH//2 - score_text.get_width()//2, HEIGHT//3))
    DISPLAY.blit(high_score_text, (WIDTH//2 - high_score_text.get_width()//2, HEIGHT//2 - 30))
    DISPLAY.blit(cause_text, (WIDTH//2 - cause_text.get_width()//2, HEIGHT//2 + 10))
    DISPLAY.blit(duration_text, (WIDTH//2 - duration_text.get_width()//2, 2*HEIGHT//3 - 30))
    DISPLAY.blit(restart_text, (WIDTH//2 - restart_text.get_width()//2, 5*HEIGHT//6))
    
    pygame.display.flip()
    
    # Update AI win/loss count
    if current_game_mode == GAME_MODE_AI_OPPONENT:
        if game_over_cause == "AI win":
            ai_wins += 1
        else:
            ai_losses += 1
    
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    waiting = False
                elif event.key == pygame.K_ESCAPE:
                    return "MENU"
    return "PLAY"

def reset_game():
    """Reset all game variables to their initial states"""
    global snake, snake_direction, ai_snake, ai_snake_direction, food, score, ai_score, powerup, powerup_timer
    global snake_length, ai_snake_length, game_over_cause, game_start_time, time_since_last_powerup
    snake = [(GRID_WIDTH // 2, GRID_HEIGHT // 2)]
    snake_direction = (1, 0)
    ai_snake = [(GRID_WIDTH // 4, GRID_HEIGHT // 4)]
    ai_snake_direction = (1, 0)
    food = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))
    score = 0
    ai_score = 0
    powerup = None
    powerup_timer = 0
    snake_length = 1
    ai_snake_length = 1
    game_over_cause = ""
    game_start_time = time.time()
    time_since_last_powerup = 0

def draw_snake():
    """Draw the player's snake on the screen"""
    for i, segment in enumerate(snake):
        if i == 0:   # Head
            pygame.draw.rect(DISPLAY, GREEN, (segment[0]*GRID_SIZE, segment[1]*GRID_SIZE, GRID_SIZE, GRID_SIZE))
            # Eyes
            eye_radius = GRID_SIZE // 8
            left_eye = (segment[0]*GRID_SIZE + GRID_SIZE // 4, segment[1]*GRID_SIZE + GRID_SIZE // 4)
            right_eye = (segment[0]*GRID_SIZE + 3*GRID_SIZE // 4, segment[1]*GRID_SIZE + GRID_SIZE // 4)
            pygame.draw.circle(DISPLAY, BLUE, left_eye, eye_radius)
            pygame.draw.circle(DISPLAY, BLUE, right_eye, eye_radius)
        else:   # Body
            pygame.draw.rect(DISPLAY, DARK_GREEN, (segment[0]*GRID_SIZE+1, segment[1]*GRID_SIZE+1, GRID_SIZE-2, GRID_SIZE-2))

def draw_ai_snake():
    """Draw the AI snake on the screen"""
    for i, segment in enumerate(ai_snake):
        if i == 0:   # Head
            pygame.draw.rect(DISPLAY, RED, (segment[0]*GRID_SIZE, segment[1]*GRID_SIZE, GRID_SIZE, GRID_SIZE))
            # Eyes
            eye_radius = GRID_SIZE // 8
            left_eye = (segment[0]*GRID_SIZE + GRID_SIZE // 4, segment[1]*GRID_SIZE + GRID_SIZE // 4)
            right_eye = (segment[0]*GRID_SIZE + 3*GRID_SIZE // 4, segment[1]*GRID_SIZE + GRID_SIZE // 4)
            pygame.draw.circle(DISPLAY, WHITE, left_eye, eye_radius)
            pygame.draw.circle(DISPLAY, WHITE, right_eye, eye_radius)
        else:   # Body
            pygame.draw.rect(DISPLAY, (200, 0, 0), (segment[0]*GRID_SIZE+1, segment[1]*GRID_SIZE+1, GRID_SIZE-2, GRID_SIZE-2))

def draw_food(time):
    """Draw the food on the screen with a pulsating effect"""
    food_radius = GRID_SIZE // 2 - 2 + int(math.sin(time * 0.1) * 2)
    food_color = (255, int(128 + math.sin(time * 0.1) * 127), 0)
    pygame.draw.circle(DISPLAY, food_color, 
                       (food[0]*GRID_SIZE + GRID_SIZE//2, food[1]*GRID_SIZE + GRID_SIZE//2), 
                       food_radius)

def draw_diamond_shape(center, size, color):
    """Draw a diamond shape for the power-up"""
    x, y = center
    points = [
        (x, y - size // 2),  # Top point
        (x + size // 2, y),  # Right point
        (x, y + size // 2),  # Bottom point
        (x - size // 2, y),  # Left point
    ]
    pygame.draw.polygon(DISPLAY, color, points)

def draw_powerup(time):
    """Draw the power-up on the screen if it exists"""
    if powerup:
        x, y = powerup
        diamond_center = (x*GRID_SIZE + GRID_SIZE//2, y*GRID_SIZE + GRID_SIZE//2)
        diamond_size = GRID_SIZE * 0.8   
        
        scale = 1 + 0.1 * math.sin(time * 0.2)
        draw_diamond_shape(diamond_center, diamond_size * scale, PINK)

# Loading and scaling the menu background image
menu_background = pygame.image.load("wallpaper.jpg")
menu_background = pygame.transform.scale(menu_background, (WIDTH, HEIGHT))

def draw_menu():
    """Draw the main menu screen"""
    DISPLAY.blit(menu_background, (0, 0))  
    
    # the start menu's text
    title = font_large.render('Modern Snake Game', True, GREEN)
    author_text = font_medium.render('By Joel Anang', True, WHITE)   
    start_text = font_medium.render('Press [ENTER] to Start', True, GREEN)
    difficulty_text = font_medium.render(f'Difficulty: {get_difficulty_name()}', True, WHITE)
    change_difficulty_text = font_medium.render('Press [D] to change difficulty', True, GREEN)
    game_mode_text = font_medium.render(f'Game Mode: {current_game_mode}', True, WHITE)
    change_game_mode_text = font_medium.render('Press [M] to change game mode', True, GREEN)
    quit_text = font_medium.render('Press [Q] to Quit', True, RED)
    mute_text = font_medium.render(f'Press [U] to {"Unmute" if is_muted else "Mute"} Music', True, GREEN)
    
    # Set spacing between menu items
    spacing = 12
    
    # Calculate total height of all menu items
    total_height = (title.get_height() + author_text.get_height() + start_text.get_height() + 
                    difficulty_text.get_height() + change_difficulty_text.get_height() +
                    game_mode_text.get_height() + change_game_mode_text.get_height() +
                    mute_text.get_height() + quit_text.get_height() + spacing * 8)
    
    # Center menu vertically
    start_y = (HEIGHT - total_height) // 2
    
    # Draw menu items
    current_y = start_y
    DISPLAY.blit(title, (WIDTH//2 - title.get_width()//2, current_y))
    current_y += title.get_height() + spacing
    DISPLAY.blit(author_text, (WIDTH//2 - author_text.get_width()//2, current_y))
    current_y += author_text.get_height() + spacing
    DISPLAY.blit(start_text, (WIDTH//2 - start_text.get_width()//2, current_y))
    current_y += start_text.get_height() + spacing
    DISPLAY.blit(difficulty_text, (WIDTH//2 - difficulty_text.get_width()//2, current_y))
    current_y += difficulty_text.get_height() + spacing
    DISPLAY.blit(change_difficulty_text, (WIDTH//2 - change_difficulty_text.get_width()//2, current_y))
    current_y += change_difficulty_text.get_height() + spacing
    DISPLAY.blit(game_mode_text, (WIDTH//2 - game_mode_text.get_width()//2, current_y))
    current_y += game_mode_text.get_height() + spacing
    DISPLAY.blit(change_game_mode_text, (WIDTH//2 - change_game_mode_text.get_width()//2, current_y))
    current_y += change_game_mode_text.get_height() + spacing
    DISPLAY.blit(mute_text, (WIDTH//2 - mute_text.get_width()//2, current_y))
    current_y += mute_text.get_height() + spacing
    DISPLAY.blit(quit_text, (WIDTH//2 - quit_text.get_width()//2, current_y))
    
    pygame.display.flip()

def get_difficulty_name():
    """Return the name of the current difficulty level"""
    if current_difficulty == DIFFICULTY_EASY:
        return "Easy"
    elif current_difficulty == DIFFICULTY_MEDIUM:
        return "Medium"
    else:
        return "Hard"

def change_difficulty():
    """Cycle through difficulty levels"""
    global current_difficulty
    if current_difficulty == DIFFICULTY_EASY:
        current_difficulty = DIFFICULTY_MEDIUM
    elif current_difficulty == DIFFICULTY_MEDIUM:
        current_difficulty = DIFFICULTY_HARD
    else:
        current_difficulty = DIFFICULTY_EASY

def change_game_mode():
    """Cycle through game modes"""
    global current_game_mode, paused_game_state
    if current_game_mode == GAME_MODE_BASIC:
        current_game_mode = GAME_MODE_AI_OPPONENT
    elif current_game_mode == GAME_MODE_AI_OPPONENT:
        current_game_mode = GAME_MODE_CAGE
    else:
        current_game_mode = GAME_MODE_BASIC
    
    # If there's a paused game, reset it as the mode has changed
    paused_game_state = None

def toggle_mute():
    """Toggle the mute state of the background music"""
    global is_muted
    is_muted = not is_muted
    if is_muted:
        pygame.mixer.music.pause()
    else:
        pygame.mixer.music.unpause()

def menu():
    """Handle the main menu logic"""
    global current_difficulty, current_game_mode, paused_game_state
    while True:
        draw_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if paused_game_state:
                        return "RESUME"
                    else:
                        return "PLAY"
                elif event.key == pygame.K_ESCAPE:
                    if paused_game_state:
                        return "RESUME" # Return to the game when Escape is pressed
                elif event.key == pygame.K_d:
                    change_difficulty()
                elif event.key == pygame.K_m:
                    change_game_mode()
                elif event.key == pygame.K_u:
                    toggle_mute()
                elif event.key == pygame.K_q:
                    quit_game()

def game_loop():
    """Main game loop"""
    global score, ai_score, snake_direction, powerup_timer, powerup, frame_count, game_duration, game_over_cause, time_since_last_powerup, paused_game_state
    time_counter = 0
    ai_move_counter = 0
    start_time = time.time()
    while True:
        frame_count += 1
        time_counter += 1
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and snake_direction != (0, 1):
                    snake_direction = (0, -1)
                elif event.key == pygame.K_DOWN and snake_direction != (0, -1):
                    snake_direction = (0, 1)
                elif event.key == pygame.K_LEFT and snake_direction != (1, 0):
                    snake_direction = (-1, 0)
                elif event.key == pygame.K_RIGHT and snake_direction != (-1, 0):
                    snake_direction = (1, 0)
                elif event.key == pygame.K_ESCAPE:
                    # Save the current game state
                    paused_game_state = {
                        'snake': snake.copy(),
                        'snake_direction': snake_direction,
                        'ai_snake': ai_snake.copy() if current_game_mode == GAME_MODE_AI_OPPONENT else None,
                        'food': food,
                        'score': score,
                        'ai_score': ai_score,
                        'powerup': powerup,
                        'powerup_timer': powerup_timer,
                        'time_since_last_powerup': time_since_last_powerup,
                        'start_time': start_time,
                        'frame_count': frame_count
                    }
                    return "MENU"
        
        # Move the player's snake
        if not move_snake():
            game_duration = time.time() - start_time
            return game_over_screen()
        
        # Move the AI snake if in AI opponent mode
        if current_game_mode == GAME_MODE_AI_OPPONENT:
            ai_move_counter += 1
            if ai_move_counter >= (current_difficulty / 4): 
                if not move_ai_snake():
                    game_duration = time.time() - start_time
                    return game_over_screen()
                ai_move_counter = 0
        
        # Draw game elements
        DISPLAY.blit(background, (0, 0))  
        draw_snake() 
        if current_game_mode == GAME_MODE_AI_OPPONENT:
            draw_ai_snake()  
        draw_food(time_counter)  
        if current_game_mode != GAME_MODE_AI_OPPONENT and powerup:
            draw_powerup(time_counter)  
        draw_score()  
        
        # Draw cage in Cage mode
        if current_game_mode == GAME_MODE_CAGE:
            pygame.draw.rect(DISPLAY, RED, (0, 0, WIDTH, HEIGHT), 3)
        
        # Draw FPS
        fps = clock.get_fps()
        fps_text = font_small.render(f'FPS: {fps:.2f}', True, WHITE)
        DISPLAY.blit(fps_text, (WIDTH - 100, HEIGHT - 30))
        
        pygame.display.flip()
        
        # Handle power-up spawning and timer
        if current_game_mode != GAME_MODE_AI_OPPONENT:
            spawn_powerup()
            if powerup_timer > 0:
                powerup_timer -= 1
                if powerup_timer == 0:
                    powerup = None
                    
        # Control game speed
        clock.tick(current_difficulty)

def quit_game():
    """Stop the music, save game metrics, and quit the game"""
    pygame.mixer.music.stop()
    save_game_metrics()
    pygame.quit()
    sys.exit()
    
# defining the game metrics for quantitative analysis 
def save_game_metrics():
    """Save game metrics to a text file"""
    with open('game_metrics.txt', 'w') as f:
        f.write(f"Game Load Time: {game_load_time:.2f} seconds\n")
        f.write(f"Final Score: {score}\n")
        f.write(f"High Score: {high_score}\n")
        f.write(f"Snake Length: {snake_length}\n")
        f.write(f"Game Duration: {game_duration:.2f} seconds\n")
        f.write(f"Game Over Cause: {game_over_cause}\n")
        f.write(f"Total Frames: {frame_count}\n")
        if game_duration > 0:
            f.write(f"Average FPS: {frame_count / game_duration:.2f}\n")
        else:
            f.write("Average FPS: N/A (game duration too short)\n")
        if current_game_mode == GAME_MODE_AI_OPPONENT:
            f.write(f"AI Score: {ai_score}\n")
            f.write(f"AI Snake Length: {ai_snake_length}\n")
            f.write(f"AI Wins: {ai_wins}\n")
            f.write(f"AI Losses: {ai_losses}\n")

# Main game loop
game_state = "MENU"
game_load_start = time.time()
while True:
    if game_state == "MENU":
        game_state = menu()
    elif game_state == "PLAY":
        reset_game()
        game_state = game_loop()
    elif game_state == "RESUME":
        if paused_game_state:
            # Restore the game state
            snake = paused_game_state['snake']
            snake_direction = paused_game_state['snake_direction']
            ai_snake = paused_game_state['ai_snake']
            food = paused_game_state['food']
            score = paused_game_state['score']
            ai_score = paused_game_state['ai_score']
            powerup = paused_game_state['powerup']
            powerup_timer = paused_game_state['powerup_timer']
            time_since_last_powerup = paused_game_state['time_since_last_powerup']
            start_time = paused_game_state['start_time']
            frame_count = paused_game_state['frame_count']
            paused_game_state = None
        game_state = game_loop()

# Making sure the game is initialized when run directly
if __name__ == "__main__":
    pygame.init()
    game_load_time = time.time() - game_load_start
    while True:
        if game_state == "MENU":
            game_state = menu()
        elif game_state == "PLAY":
            reset_game()
            game_state = game_loop()
        elif game_state == "RESUME":
            game_state = game_loop()